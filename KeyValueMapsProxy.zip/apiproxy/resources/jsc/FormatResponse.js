var kvmResponse = JSON.parse(context.getVariable("response.content"));
var entries = kvmResponse.entry;

var keys = [];
for (var i = 0; i < entries.length; i++) {
  keys.push(entries[i].name);
}

var responseObject = {
  "encrypted": kvmResponse.encrypted,
  "entry": [],
  "name": kvmResponse.name,
};

while (keys.length >= 0) {
  print("running");
  var keyBatch = keys.splice(0, 10);
  var headers = {
    "Content-Type": "application/json",
    "Client-Id": context.getVariable("request.header.Client-Id"),
    "Authorization": "Bearer " + context.getVariable("apigee.access_token"),
  };
  var exchange = httpClient.send(
    new Request(
      "https://" + getHost() + "/keyvaluemaps/v1/entries/" +
        context.getVariable("mapIdentifier"),
      "GET",
      headers,
      JSON.stringify(keyBatch)
    )
  );
  print("here");
  exchange.waitForComplete();
  if (exchange.isSuccess()) {
    print("success");
    var statusCode = exchange.getResponse().status;
    if (statusCode == 500) {
      var responseContent = {
        code: "Custom.Error.DynamicKeyValueMaps.NoMatch",
        message: "No KeyValueMap with the name '" +
          decodeURI(context.getVariable("mapIdentifier")) +
          "' could be found. If this KVM exists, please update the DynamicKeyValueMaps shared flow to include a match for the KVM's mapIdentifier/name (Case-sensitive).",
        contexts: [],
      };
      context.setVariable("response.status.code", 500);
      context.setVariable("response.content", JSON.stringify(responseContent));
      break;
    }

    var response = exchange.getResponse();
    var entry = responseObject.entry;
    responseObject.entry = entry.concat(JSON.parse(response.content));
  } else if (exchange.isError()) {
    var error = exchange.getError();
    throw new Error(exchange.getError());
  }

  if (keys.length === 0) {
     print("entered");
    context.setVariable("message.content", JSON.stringify(responseObject));
    context.setVariable("message.header.Content-Type", "application/json");
    break;
  }
}

function getHost() {
  var alternateHost = context.getVariable(
    "request.header.KeyValueMaps-Alternate-Host"
  );
  if (!alternateHost) {
    // var protocol = context.getVariable("virtualhost.ssl.enabled") ? "https://" : "http://";
    return JSON.parse(context.getVariable("virtualhost.aliases.values"))[0];
  }
  return alternateHost;
}
